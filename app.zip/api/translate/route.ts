import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const { text, targetLang } = await req.json();

  try {
    // OpenAI translation is temporarily disabled
    // const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });
    // const response = await openai.chat.completions.create({
    //   model: "gpt-3.5-turbo",
    //   messages: [
    //     { role: "system", content: `Translate to ${targetLang}` },
    //     { role: "user", content: text }
    //   ]
    // });
    // const translated = response.choices[0].message.content;

    // Return original text as fallback
    return NextResponse.json({ translated: text });
  } catch (error) {
    console.error("Translation skipped (OpenAI not connected):", error);
    return NextResponse.json({ translated: text });
  }
}
