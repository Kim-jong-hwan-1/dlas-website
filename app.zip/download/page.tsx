export default function DownloadPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Download</h1>
      <p>Here you will be able to download our software and updates.</p>
    </div>
  );
}