export default function ContactPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Contact Us</h1>
      <p>Please reach out to us at support@dlas.io</p>
    </div>
  );
}