export default function NotFound() {
  return (
    <div style={{ padding: 40 }}>
      <h1>404 - Page Not Found</h1>
      <p>We couldn’t find what you were looking for.</p>
    </div>
  );
}